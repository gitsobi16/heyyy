// script.js

// Get all "Book Appointment" buttons
const openFormButtons = document.querySelectorAll('.open-form-btn');

// Get the modal element
const modal = document.getElementById('form-modal');

// Get the close button inside the modal
const closeBtn = document.querySelector('.close-btn');

// Get modal title and doctor name input
const modalTitle = document.getElementById('modal-title');
const doctorNameInput = document.getElementById('doctor-name');

// Add event listeners to each "Book Appointment" button
openFormButtons.forEach(button => {
    button.addEventListener('click', () => {
        const doctorName = button.getAttribute('data-doctor');
        // Update modal title and hidden input value
        modalTitle.textContent = `Schedule an Appointment with ${doctorName}`;
        doctorNameInput.value = doctorName;
        // Show the modal
        modal.style.display = 'block';
    });
});

// Add event listener to close button
closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Close the modal if the user clicks outside the modal content
window.addEventListener('click', (e) => {
    if (e.target == modal) {
        modal.style.display = 'none';
    }
});
